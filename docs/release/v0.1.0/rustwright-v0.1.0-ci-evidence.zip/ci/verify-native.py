import pathlib,json,re,hashlib,collections,subprocess,struct
ROOT=pathlib.Path(__file__).resolve().parent
CI=ROOT
HEAD="fadb3463297fb611915cc8fc92a4b1a91f196f15";MERGE="87f6180e4922ca860e10f91701e6032e6cb85390"
ANSI=re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
RESULT=re.compile(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;")
def save(base,name,data):(base/name).write_text(json.dumps(data,indent=2)+"\n")
# Full-workspace FIFO avoids stdout/stderr interleaving causing shifted categorization.
queue=collections.deque();suites=[];log=CI/"jobs/114084276153.log";lines=ANSI.sub("",log.read_text()).splitlines()
for n,line in enumerate(lines,1):
 m=re.search(r"Running (unittests )?([^ ]+) \(([^)]+)\)",line)
 if m:
  unit,source,binary=m.groups();name=pathlib.PurePosixPath(binary).name.rsplit("-",1)[0]
  kind=("library" if source=="src/lib.rs" else "example") if unit else ("http" if name.startswith("http_") else "legacy-integration" if name in ["advanced","bidi","diagnostics","features","unified","vertical_slice"] else "runner-integration")
  queue.append({"kind":kind,"name":name,"start_line":n})
 m=re.search(r"Doc-tests ([^ ]+)",line)
 if m:queue.append({"kind":"doctest","name":m[1],"start_line":n})
 m=RESULT.search(line)
 if m:
  assert queue;item=queue.popleft();item.update(status=m[1],passed=int(m[2]),failed=int(m[3]),ignored=int(m[4]),measured=int(m[5]),filtered=int(m[6]),result_line=n);suites.append(item)
assert not queue
keys=["passed","failed","ignored","filtered"];totals={k:sum(x[k] for x in suites) for k in keys};assert totals==dict(passed=480,failed=0,ignored=1,filtered=0)
scopes={}
for x in suites:
 d=scopes.setdefault(x["kind"],dict.fromkeys(keys,0))
 for k in keys:d[k]+=x[k]
regressions={}
for fn in ["startup_replacement_does_not_fail_or_duplicate_default_page_allocation","startup_replacement_preserves_isolated_page_owner_and_activation","foreground_protocol_control_fails_after_allocating_on_replacement","cancelled_activation_retires_allocated_page_before_initialization","failed_activation_retires_allocated_page_before_initialization"]:
 matches=[{"line":n+1,"raw":line} for n,line in enumerate(lines) if re.search(r"test browser::[^ ]*::"+fn+r" \.\.\. ok$",line)];assert len(matches)==1;regressions[fn]=matches[0]
save(CI,"workspace-counts.json",{"totals":totals,"scopes":scopes,"suites":suites,"new5_regressions":regressions,"scope":"HTTP results overlap dedicated native jobs; do not sum as unique coverage."})
# Native reports, actual per-target summaries/names, foreground startup-cycle markers.
native={};markers=[]
for osname in ["windows-latest","macos-latest","ubuntu-latest"]:
 for scope in ["portable","linux-extra"]:
  base=CI/f"artifacts/native-http-{osname}/{scope}";p=base/"report.json"
  if not p.exists():continue
  report=json.loads(p.read_bytes());assert report["status"]=="passed";counts=dict.fromkeys(keys,0);targets=[];backend=collections.Counter()
  for case in report["cases"]:
   s=ANSI.sub("",(base/(case["target"]+".log")).read_text());m=RESULT.findall(s);assert len(m)==1 and m[0][0]=="ok";v=dict(zip(keys,map(int,[m[0][1],m[0][2],m[0][3],m[0][5]])));assert case["exit_code"]==0 and all(case[k]==val for k,val in v.items()) and v["failed"]==v["ignored"]==v["filtered"]==0
   names=re.findall(r"^test ((?:chrome|firefox)_[^ ]+) \.\.\.",s,re.M)
   if scope=="portable":assert len(names)==v["passed"];backend.update(n.split("_",1)[0] for n in names)
   targets.append({"target":case["target"],**v})
   for k,val in v.items():counts[k]+=val
  assert counts["passed"]==report["passed"]==(79 if scope=="portable" else 114)
  native.setdefault(osname,{})[scope]={"totals":counts,"targets":targets,"cases_by_backend":dict(backend) if scope=="portable" else None}
for p in (CI/"artifacts").rglob("http_network_idle_parity.log"):
 s=p.read_text();matches=re.findall(r"page_closure startup cycle=(\d+)/5 backend=firefox",s);assert matches==["1","2","3","4","5"];markers.append({"log":str(p.relative_to(CI)),"successful_firefox_startup_cycles":matches,"foreground_assertion_active_in_exact_source":True})
assert len(markers)==5
workspace_cycles=re.findall(r"page_closure startup cycle=(\d+)/5 backend=firefox",log.read_text());assert not workspace_cycles
save(CI,"native-counts.json",native);save(CI,"firefox-startup-cycle-confirmations-final.json",{"five_native_commands":markers,"native_cycle_count":25,"workspace_marker_lines":workspace_cycles,"workspace_scope":"Passing workspace tests capture stdout/stderr; no individual startup-cycle lines emitted. Named closure test passed, but raw25-cycle proof comes from five dedicated native commands.","scope":"Repeated first-page startup/visibility assertions within the existing named tests; these are not additional79-case counts."})

print("Main CI workspace/native audit passed:480workspace;79eachOS+114Ubuntu;25Firefoxstartupmarkers.")
