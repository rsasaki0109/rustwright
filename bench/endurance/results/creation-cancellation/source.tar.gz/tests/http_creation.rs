//! Deterministically cancel real browser allocations after remote execution.
use futures_util::{SinkExt, StreamExt};
use rustwright::{
    bidi::{BidiBrowser, BidiContext},
    browser::{LaunchedBrowser, LaunchedFirefox},
    cdp::CdpConnection,
    prelude::*,
    AnyError,
};
use serde_json::{json, Value};
use std::{path::PathBuf, result::Result as TestResult, sync::Arc, time::Duration};
use tokio::{
    io::{AsyncReadExt, AsyncWriteExt},
    net::TcpListener,
    sync::{mpsc, oneshot},
    task::{JoinHandle, JoinSet},
};
use tokio_tungstenite::{accept_async, connect_async, tungstenite::Message};

const LIMIT: Duration = Duration::from_secs(5);
struct Gate {
    method: &'static str,
    armed: oneshot::Sender<()>,
    entered: oneshot::Sender<()>,
    release: oneshot::Receiver<()>,
}
struct Proxy {
    endpoint: String,
    control: mpsc::UnboundedSender<Gate>,
    task: JoinHandle<()>,
}
impl Drop for Proxy {
    fn drop(&mut self) {
        self.task.abort();
    }
}
impl Proxy {
    async fn arm(&self, method: &'static str) -> (oneshot::Receiver<()>, oneshot::Sender<()>) {
        let (armed, ready) = oneshot::channel();
        let (entered, waiting) = oneshot::channel();
        let (release, released) = oneshot::channel();
        self.control
            .send(Gate {
                method,
                armed,
                entered,
                release: released,
            })
            .unwrap();
        tokio::time::timeout(LIMIT, ready).await.unwrap().unwrap();
        (waiting, release)
    }
}
async fn proxy(upstream: String) -> Proxy {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let endpoint = format!("ws://{}/session", listener.local_addr().unwrap());
    let (control, mut commands) = mpsc::unbounded_channel::<Gate>();
    let task = tokio::spawn(async move {
        let (socket, _) = listener.accept().await.unwrap();
        let mut client = accept_async(socket).await.unwrap();
        let (mut browser, _) = connect_async(&upstream).await.unwrap();
        let mut active: Option<(String, oneshot::Sender<()>, oneshot::Receiver<()>)> = None;
        let mut held_id: Option<Value> = None;
        let mut held_reply: Option<Message> = None;
        loop {
            tokio::select! {
                gate = commands.recv() => {
                    let Some(gate) = gate else { break; };
                    assert!(active.is_none());
                    active = Some((gate.method.to_owned(), gate.entered, gate.release));
                    gate.armed.send(()).unwrap();
                },
                _ = async { (&mut active.as_mut().unwrap().2).await }, if held_reply.is_some() => {
                    client.send(held_reply.take().unwrap()).await.unwrap();
                    active = None;
                    held_id = None;
                },
                message = client.next() => {
                    let Some(Ok(message)) = message else { break; };
                    if message.is_close() { break; }
                    if message.is_text() {
                        let command: Value = serde_json::from_str(message.to_text().unwrap()).unwrap();
                        if active.as_ref().is_some_and(|gate| command["method"] == gate.0) && held_id.is_none() {
                            held_id = Some(command["id"].clone());
                        }
                    }
                    if browser.send(message).await.is_err() { break; }
                },
                message = browser.next() => {
                    let Some(Ok(message)) = message else { break; };
                    if message.is_close() { break; }
                    if message.is_text() && held_id.is_some() {
                        let response: Value = serde_json::from_str(message.to_text().unwrap()).unwrap();
                        if held_id.as_ref() == Some(&response["id"]) {
                            assert!(response.get("error").is_none(), "allocation must succeed remotely: {response}");
                            held_reply = Some(message);
                            let gate = active.as_mut().unwrap();
                            let (replacement, _) = oneshot::channel();
                            std::mem::replace(&mut gate.1, replacement).send(()).unwrap();
                            continue;
                        }
                    }
                    if client.send(message).await.is_err() { break; }
                },
            }
        }
    });
    Proxy {
        endpoint,
        control,
        task,
    }
}

struct Fixture {
    url: String,
    profile: PathBuf,
    task: JoinHandle<()>,
}
impl Drop for Fixture {
    fn drop(&mut self) {
        self.task.abort();
        let _ = std::fs::remove_dir_all(&self.profile);
    }
}
async fn fixture(firefox: bool) -> Fixture {
    let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let profile = std::env::temp_dir().join(format!(
        "rustwright-create-{}-{}-{}",
        std::process::id(),
        firefox,
        address.port()
    ));
    let task = tokio::spawn(async move {
        let mut requests = JoinSet::new();
        loop {
            tokio::select! {
                accepted=listener.accept()=> {
                    let (mut socket,_)=accepted.unwrap();
                    requests.spawn(async move {
                        let mut request=Vec::new();
                        loop {
                            let mut bytes=[0;2048];
                            let Ok(n)=socket.read(&mut bytes).await else { return; };
                            if n==0 {return;}
                            request.extend_from_slice(&bytes[..n]);
                            if request.len()>16*1024 {return;}
                            if request.windows(4).any(|b|b==b"\r\n\r\n") {break;}
                        }
                        let body="<!DOCTYPE html><title>creation</title><input id=q>";
                        let response=format!("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{body}",body.len());
                        let _=socket.write_all(response.as_bytes()).await;
                    });
                },
                _=requests.join_next(),if !requests.is_empty()=>{},
            }
        }
    });
    Fixture {
        url: format!("http://{address}/creation.html"),
        profile,
        task,
    }
}
enum Engine {
    Chrome(Arc<Browser>, CdpConnection),
    Firefox(Arc<BidiBrowser>),
}
enum Context {
    Chrome(BrowserContext),
    Firefox(BidiContext),
}
impl Context {
    async fn new_page(&self) -> TestResult<AnyPage, AnyError> {
        match self {
            Self::Chrome(c) => Ok(c.new_page().await?.into()),
            Self::Firefox(c) => Ok(c.new_page().await?.into()),
        }
    }
    async fn close(&self) {
        match self {
            Self::Chrome(c) => c.close().await.unwrap(),
            Self::Firefox(c) => c.close().await.unwrap(),
        }
    }
}
impl Engine {
    async fn new_context(&self) -> TestResult<Context, AnyError> {
        match self {
            Self::Chrome(b, _) => Ok(Context::Chrome(b.new_context().await?)),
            Self::Firefox(b) => Ok(Context::Firefox(b.new_context().await?)),
        }
    }
    async fn new_page(&self) -> TestResult<AnyPage, AnyError> {
        match self {
            Self::Chrome(b, _) => Ok(b.new_page().await?.into()),
            Self::Firefox(b) => Ok(b.new_page().await?.into()),
        }
    }
    fn pending(&self) -> usize {
        match self {
            Self::Chrome(b, _) => b.pending_command_count(),
            Self::Firefox(b) => b.session().connection().pending_command_count(),
        }
    }
    async fn counts(&self) -> Counts {
        let (mut pages, mut owners, helpers) = match self {
            Self::Chrome(_, observer) => {
                let pages = observer
                    .send_raw(None, "Target.getTargets", json!({}))
                    .await
                    .unwrap();
                let owners = observer
                    .send_raw(None, "Target.getBrowserContexts", json!({}))
                    .await
                    .unwrap();
                (
                    pages["targetInfos"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .filter(|p| p["type"] == "page")
                        .map(|p| p["targetId"].as_str().unwrap().to_owned())
                        .collect::<Vec<_>>(),
                    owners["browserContextIds"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .map(|p| p.as_str().unwrap().to_owned())
                        .collect::<Vec<_>>(),
                    None,
                )
            }
            Self::Firefox(b) => {
                let owners = b
                    .session()
                    .connection()
                    .send("browser.getUserContexts", json!({}))
                    .await
                    .unwrap();
                (
                    b.session()
                        .get_tree()
                        .await
                        .unwrap()
                        .into_iter()
                        .filter(|p| p.parent.is_none())
                        .map(|p| p.context)
                        .collect::<Vec<_>>(),
                    owners["userContexts"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .map(|p| p["userContext"].as_str().unwrap().to_owned())
                        .collect::<Vec<_>>(),
                    Some(b.session().helper_preload_count()),
                )
            }
        };
        pages.sort();
        owners.sort();
        Counts {
            pages,
            owners,
            helpers,
        }
    }
    async fn close(self) {
        match self {
            Self::Chrome(b, observer) => {
                b.close().await.unwrap();
                observer.close();
            }
            Self::Firefox(b) => Arc::try_unwrap(b).unwrap().close().await.unwrap(),
        }
    }
}
#[derive(Debug, PartialEq, Eq)]
struct Counts {
    pages: Vec<String>,
    owners: Vec<String>,
    helpers: Option<usize>,
}
async fn restored(engine: &Engine, baseline: &Counts) {
    tokio::time::timeout(LIMIT,async {
        loop {
            if engine.counts().await==*baseline && engine.pending()==0 {break;}
            tokio::time::sleep(Duration::from_millis(5)).await;
        }
    }).await.expect("cancelled allocations must restore exact page/context IDs, helper ledger and pending count");
}
async fn healthy(page: &AnyPage, url: &str) {
    page.goto(url).await.unwrap();
    assert_eq!(page.title().await.unwrap(), "creation");
    page.locator("#q")
        .fill("作成キャンセル後 Rust")
        .await
        .unwrap();
    assert_eq!(
        page.evaluate("document.querySelector('#q').value")
            .await
            .unwrap(),
        json!("作成キャンセル後 Rust")
    );
}
async fn scenario(firefox: bool) {
    let fixture = fixture(firefox).await;
    let chrome;
    let firefox_process;
    let upstream = if firefox {
        firefox_process = LaunchedFirefox::launch(
            &Firefox::installed()
                .headless(true)
                .profile(&fixture.profile),
        )
        .await
        .expect("Firefox must start; no skip");
        firefox_process.ws_url().to_owned()
    } else {
        chrome = LaunchedBrowser::launch(&Chrome::installed().headless(true))
            .await
            .expect("Chrome must start; no skip");
        chrome.ws_url().to_owned()
    };
    let proxy = proxy(upstream.clone()).await;
    let engine = Arc::new(if firefox {
        Engine::Firefox(Arc::new(
            BidiBrowser::connect(&proxy.endpoint).await.unwrap(),
        ))
    } else {
        Engine::Chrome(
            Arc::new(Browser::connect(&proxy.endpoint).await.unwrap()),
            CdpConnection::connect(&upstream).await.unwrap(),
        )
    });
    let version = match &*engine {
        Engine::Chrome(browser, _) => browser.version().browser.clone(),
        Engine::Firefox(browser) => browser.browser_version().unwrap().to_owned(),
    };
    let keeper = engine.new_page().await.unwrap();
    healthy(&keeper, &fixture.url).await;
    let initial = engine.counts().await;
    for mode in [
        "context",
        "default-create",
        "default-init",
        "isolated-create",
        "isolated-init",
    ] {
        let context = if mode.starts_with("isolated") {
            Some(Arc::new(engine.new_context().await.unwrap()))
        } else {
            None
        };
        let baseline = engine.counts().await;
        let method = match (firefox, mode) {
            (false, "context") => "Target.createBrowserContext",
            (true, "context") => "browser.createUserContext",
            (false, "default-init" | "isolated-init") => "Page.enable",
            (true, "default-init" | "isolated-init") => "script.addPreloadScript",
            (false, _) => "Target.createTarget",
            (true, _) => "browsingContext.create",
        };
        for cycle in 1..=10 {
            let (entered, release) = proxy.arm(method).await;
            let caller = engine.clone();
            let owner = context.clone();
            let task = tokio::spawn(async move {
                if mode == "context" {
                    caller.new_context().await.map(|_| ())
                } else if let Some(owner) = owner {
                    owner.new_page().await.map(|_| ())
                } else {
                    caller.new_page().await.map(|_| ())
                }
            });
            tokio::time::timeout(LIMIT, entered).await.unwrap().unwrap();
            assert!(
                engine.pending() > 0,
                "the caller must be awaiting the held response"
            );
            task.abort();
            assert!(task.await.unwrap_err().is_cancelled());
            release.send(()).unwrap();
            restored(&engine, &baseline).await;
            assert_eq!(keeper.title().await.unwrap(), "creation");
            let page = if let Some(context) = &context {
                context.new_page().await.unwrap()
            } else {
                engine.new_page().await.unwrap()
            };
            healthy(&page, &fixture.url).await;
            page.close().await.unwrap();
            restored(&engine, &baseline).await;
            eprintln!(
                "{}",
                json!({"engine":if firefox {"firefox"} else {"chrome"},"mode":mode,"cycle":cycle,"pending":engine.pending(),"pages":baseline.pages.len(),"contexts":baseline.owners.len(),"helper_preloads":baseline.helpers,"version":version,"page_ids":baseline.pages,"context_ids":baseline.owners,"existing_page_preserved":true,"subsequent_page_usable":true})
            );
        }
        if let Some(context) = context {
            context.close().await;
        }
        restored(&engine, &initial).await;
    }
    keeper.close().await.unwrap();
    drop(keeper);
    Arc::try_unwrap(engine).ok().unwrap().close().await;
}
#[tokio::test]
async fn chrome_cancelled_creation_releases_native_resources() {
    scenario(false).await;
}
#[tokio::test]
async fn firefox_cancelled_creation_releases_native_resources() {
    scenario(true).await;
}
